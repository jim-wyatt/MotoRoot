#!/system/bin/sh
# dev_wireguard: bring up the aosp-academy WireGuard tunnel (wg0) on the stock system at boot, the
# same tunnel the aosp-academy image brings up, so the device node reaches the phone over the
# tunnel on either system (aosp-academy deploy can then run without a cable).
#
# Everything private lives in /data/adb/aospacademy-wg (Magisk's root-only area, kept across
# reboots; stock's data is never wiped by a deploy): wg (built from the pinned wireguard-tools),
# wg0.conf (wg setconf format: the phone's private key and the hub peer) and wg0.env (ADDRESS4=,
# ADDRESS6=, ROUTES4=, ROUTES6=). aosp-academy stock tunnel puts them there. Without them, nothing
# happens. The kernel has WireGuard built in. Android routes by policy per network, so the
# tunnel's subnets get a table of their own (1999) and a rule ahead of the per-network rules.
# Traffic from the tunnel address also uses that table, which has a default route into wg0, so
# the phone answers over the tunnel whoever reached it there, including a PC on a subnet the hub
# routes that isn't in ROUTES4. Everything else stock sends keeps using Wi-Fi.
# The result goes to /data/adb/aospacademy-wg/status. Disable the module and reboot to stop it.
D=/data/adb/aospacademy-wg
# Magisk runs module scripts in BusyBox's shell, where a bare `ip` is BusyBox's, which can't add
# the policy-routing table and rule below (wg0 came up, but nothing could answer through it).
# Android's own ip can.
IP=/system/bin/ip
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
[ -x "$D/wg" ] && [ -f "$D/wg0.conf" ] && [ -f "$D/wg0.env" ] || exit 0
umask 077
result() { echo "$*" > "$D/status"; log -t dev_wireguard "$*"; exit 0; }
# tr -d '\r': a wg0.env written on Windows has CRLF line ends.
val() { sed -n "s/^$1=//p" "$D/wg0.env" | head -n 1 | tr -d '\r'; }
a4="$(val ADDRESS4)"; a6="$(val ADDRESS6)"; r4="$(val ROUTES4)"; r6="$(val ROUTES6)"
"$IP" link del wg0 2>/dev/null
"$IP" link add wg0 type wireguard || result "failed: the kernel refused a wireguard link"
"$D/wg" setconf wg0 "$D/wg0.conf" || { "$IP" link del wg0; result "failed: wg setconf"; }
[ -n "$a4" ] && "$IP" addr add "$a4" dev wg0
[ -n "$a6" ] && "$IP" -6 addr add "$a6" dev wg0
"$IP" link set wg0 up || result "failed: wg0 did not come up"
for r in $r4; do
    "$IP" route replace "$r" dev wg0 table 1999
    "$IP" rule del to "$r" lookup 1999 2>/dev/null
    "$IP" rule add to "$r" lookup 1999 priority 9000
done
for r in $r6; do
    "$IP" -6 route replace "$r" dev wg0 table 1999
    "$IP" -6 rule del to "$r" lookup 1999 2>/dev/null
    "$IP" -6 rule add to "$r" lookup 1999 priority 9000
done
# Replies: from the tunnel address, back into the tunnel (the default here is only for them).
if [ -n "$a4" ]; then
    "$IP" route replace default dev wg0 table 1999
    "$IP" rule del from "${a4%/*}" lookup 1999 2>/dev/null
    "$IP" rule add from "${a4%/*}" lookup 1999 priority 9000
fi
if [ -n "$a6" ]; then
    "$IP" -6 route replace default dev wg0 table 1999
    "$IP" -6 rule del from "${a6%/*}" lookup 1999 2>/dev/null
    "$IP" -6 rule add from "${a6%/*}" lookup 1999 priority 9000
fi
[ -z "$r4" ] || "$IP" rule | grep -q "lookup 1999" || result "failed: no routing rule for the tunnel's subnets"
result "up ${a4%/*}"
